<?php   
class WTC_AjaxNewsletter_Block_Index extends Mage_Core_Block_Template{   





}