<?php   
class WTC_AjaxNewsletter_Block_Left extends Mage_Core_Block_Template{   





}